# GPS SIM Monitor — récepteur push 18gps.net

Petit serveur qui reçoit les données poussées en temps réel par la plateforme
18gps.net (interface "Push Edition") et affiche un tableau de bord indiquant
quels trackers/SIM sont **en ligne** ou **hors ligne**.

## Comment ça marche

1. Ce serveur expose 3 endpoints, exactement ceux demandés dans la doc du
   fournisseur :
   - `GET/POST /pushTest` — interface de test (supporte JSONP)
   - `POST /status` — reçoit la position + l'état de chaque tracker
   - `POST /alarm` — reçoit les alarmes
2. À chaque réception d'un `status`, le serveur enregistre l'horodatage
   **côté serveur** (`lastServerSeenAt`) pour chaque appareil (`Macid` /
   IMEI).
3. Un appareil est affiché **hors ligne** si aucune donnée n'a été reçue
   depuis plus de `OFFLINE_AFTER_MIN` minutes (15 par défaut). C'est
   l'indicateur le plus fiable : si la plateforme ne pousse plus rien pour
   un device, c'est que la SIM/le tracker ne communique plus.
4. Le tableau de bord (`/index.html`) interroge `/api/devices` toutes les
   10 secondes et affiche l'état de chaque appareil.

## Installation locale (pour tester)

```bash
npm install
npm start
```

Le serveur écoute par défaut sur le port `7070`. Ouvre
`http://localhost:7070` pour voir le tableau de bord (vide au départ,
tant qu'aucune donnée n'a été poussée).

Tu peux simuler un push de test toi-même :

```bash
curl "http://localhost:7070/pushTest?method=PushTest&serialNumber=7019"
# doit renvoyer : 7019
```

## Mise en production (obligatoire pour que 18gps.net puisse te joindre)

Le point important : **18gps.net doit pouvoir atteindre ton serveur depuis
Internet**, donc `localhost` ne suffit pas. Il te faut une URL publique en
HTTPS. Options simples, du plus facile au plus contrôlé :

- **Railway** ou **Render** (offres gratuites/pas chères) : tu connectes
  ton dépôt Git, ça déploie l'app automatiquement et te donne une URL du
  type `https://ton-projet.up.railway.app`.
- **Un VPS** (par ex. un petit serveur chez un hébergeur local ou
  DigitalOcean/OVH) avec Node.js installé, et un reverse proxy (Nginx +
  certificat Let's Encrypt) devant pour avoir du HTTPS.
- **Pour un test rapide seulement** (pas pour la production) : `ngrok`
  peut exposer temporairement ton serveur local avec une URL publique.

### Variables d'environnement utiles

| Variable | Rôle | Défaut |
|---|---|---|
| `PORT` | Port d'écoute | `7070` |
| `OFFLINE_AFTER_MIN` | Minutes sans donnée avant de marquer "hors ligne" | `15` |
| `DASHBOARD_TOKEN` | Si défini, protège le tableau de bord et l'API par un jeton (`?token=...`) | vide (pas de protection) |

**Recommandé en production** : définis `DASHBOARD_TOKEN` pour que ton
tableau de bord ne soit pas visible par n'importe qui tombant sur l'URL.

## Étapes avec le technicien 18gps.net

1. Déploie ce serveur, note son URL publique, par exemple :
   `https://mon-suivi-sim.up.railway.app`
2. Donne-lui les 3 adresses complètes :
   - `https://mon-suivi-sim.up.railway.app/pushTest`
   - `https://mon-suivi-sim.up.railway.app/status`
   - `https://mon-suivi-sim.up.railway.app/alarm`
3. Donne-lui ton compte de la plateforme et le type de coordonnées
   souhaité (Google, Baidu, Tencent ou AutoNavi — peu importe pour ton
   usage, ça ne change que l'affichage sur une carte).
4. Vérifie que tous tes trackers restent en ligne sous ce compte pendant
   la configuration — sinon il n'y aura pas de données à pousser.
5. Une fois configuré, laisse tourner quelques minutes et vérifie ton
   tableau de bord : les appareils doivent apparaître avec leur statut.

## Limites de cette version (MVP)

- Stockage dans un simple fichier `devices.json` sur disque — suffisant
  pour quelques dizaines/centaines de trackers, mais si tu déploies sur
  une plateforme qui réinitialise le disque à chaque redéploiement
  (certaines offres gratuites), l'historique sera perdu (l'état courant
  se reconstruit tout seul au push suivant, donc ce n'est pas bloquant).
- Pas encore d'alertes automatiques (email/SMS/Telegram) quand un
  tracker passe hors ligne — facile à ajouter si tu veux, dis-le moi.
- Pas encore d'affichage sur une carte — seulement liste + statut.
