// Recupere ?token=... dans l'URL du dashboard s'il y en a un
// (utile si DASHBOARD_TOKEN est configure cote serveur)
const urlToken = new URLSearchParams(window.location.search).get("token") || "";

function fmtAgo(sec) {
  if (sec === null || sec === undefined) return "jamais";
  if (sec < 60) return `${sec}s`;
  if (sec < 3600) return `${Math.floor(sec / 60)} min`;
  return `${Math.floor(sec / 3600)} h ${Math.floor((sec % 3600) / 60)} min`;
}

function fmtTimestamp(ms) {
  if (!ms) return "-";
  const n = Number(ms);
  if (!n) return "-";
  return new Date(n).toLocaleString("fr-FR");
}

async function refresh() {
  try {
    const url = "/api/devices" + (urlToken ? `?token=${encodeURIComponent(urlToken)}` : "");
    const res = await fetch(url);
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();

    document.getElementById("threshold").textContent = data.offlineAfterMin;

    const rows = document.getElementById("rows");
    const empty = document.getElementById("empty");
    rows.innerHTML = "";

    if (!data.devices.length) {
      empty.style.display = "block";
    } else {
      empty.style.display = "none";
    }

    let online = 0;
    data.devices.forEach((d) => {
      if (d.status === "online") online++;
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td class="${d.status}"><span class="dot"></span><span class="status-label ${d.status}">${d.status === "online" ? "En ligne" : "Hors ligne"}</span></td>
        <td>${d.macid}</td>
        <td>${fmtAgo(d.lastServerSeenAgoSec)}</td>
        <td>${fmtTimestamp(d.heartTime)}</td>
        <td>${d.speed ?? "-"}</td>
        <td>${d.lastAlarm ? (d.lastAlarm.describe || d.lastAlarm.classify || "oui") : "-"}</td>
      `;
      rows.appendChild(tr);
    });

    document.getElementById("count-total").textContent = data.devices.length;
    document.getElementById("count-online").textContent = online;
    document.getElementById("count-offline").textContent = data.devices.length - online;
  } catch (err) {
    console.error("Erreur de rafraichissement:", err);
  }
}

refresh();
setInterval(refresh, 10000);
