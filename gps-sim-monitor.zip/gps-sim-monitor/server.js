// server.js
// Recoit les donnees "push" envoyees par la plateforme 18gps.net
// (endpoints PushTest / status / alarm, cf. doc technique du fournisseur)
// et expose un petit tableau de bord pour voir quelles SIM/trackers
// sont en ligne ou hors ligne.

const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();

// La plateforme envoie du form-urlencoded (method=status&serialNumber=...&data=[...])
app.use(express.urlencoded({ extended: true, limit: "2mb" }));
app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

// ---------------------------------------------------------------------
// Config
// ---------------------------------------------------------------------
const PORT = process.env.PORT || 7070;
// Au bout de combien de temps sans nouvelle donnee on considere
// un tracker/SIM comme hors ligne (en minutes).
const OFFLINE_AFTER_MIN = Number(process.env.OFFLINE_AFTER_MIN || 15);
// Jeton simple pour proteger le tableau de bord / l'API de lecture.
// Laisser vide en local pour tester, mais A DEFINIR en production.
const DASHBOARD_TOKEN = process.env.DASHBOARD_TOKEN || "";

const DB_FILE = path.join(__dirname, "devices.json");

// ---------------------------------------------------------------------
// Stockage tres simple sur disque (un fichier JSON).
// Suffisant pour quelques dizaines/centaines de trackers.
// A remplacer par une vraie base (SQLite/Postgres) si le volume grossit.
// ---------------------------------------------------------------------
function loadDevices() {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  } catch {
    return {};
  }
}

function saveDevices(devices) {
  fs.writeFileSync(DB_FILE, JSON.stringify(devices, null, 2));
}

function upsertDeviceFromStatus(entry) {
  const devices = loadDevices();
  const id = entry.Macid || entry.macid;
  if (!id) return;

  const now = Date.now();

  devices[id] = {
    ...(devices[id] || {}),
    macid: id,
    lastServerSeenAt: now, // horodatage cote SERVEUR : le plus fiable pour "en ligne / hors ligne"
    gpsTime: entry.GpsTime || null,
    heartTime: entry.HeartTime || null,
    updTime: entry.UpdTime || null,
    lat: entry.Lat || null,
    lon: entry.Lon || null,
    mapLat: entry.MapLat || null,
    mapLon: entry.MapLon || null,
    speed: entry.Speed || null,
    dir: entry.Dir || null,
    stats: entry.Stats || entry["Stats "] || null,
    value: entry.Value || entry["Value "] || null,
    lastAlarm: devices[id] ? devices[id].lastAlarm : null,
  };

  saveDevices(devices);
}

function recordAlarm(entry) {
  const devices = loadDevices();
  const id = entry.Macid;
  if (!id) return;

  devices[id] = devices[id] || { macid: id };
  devices[id].lastAlarm = {
    id: entry.Id,
    classify: entry.Classify,
    describe: entry.Describe,
    time: entry.PTime,
    receivedAt: Date.now(),
  };
  saveDevices(devices);
}

function computeStatus(device) {
  if (!device.lastServerSeenAt) return "offline";
  const ageMin = (Date.now() - device.lastServerSeenAt) / 60000;
  return ageMin <= OFFLINE_AFTER_MIN ? "online" : "offline";
}

// ---------------------------------------------------------------------
// 1) PushTest : interface de test obligatoire (avec support JSONP)
// ---------------------------------------------------------------------
app.all("/pushTest", (req, res) => {
  const params = { ...req.query, ...req.body };
  const serialNumber = params.serialNumber || "";
  const callback = params.callback;

  if (callback) {
    res.type("application/javascript");
    return res.send(`${callback}("${serialNumber}")`);
  }
  res.type("text/plain");
  return res.send(String(serialNumber));
});

// ---------------------------------------------------------------------
// 2) status : position + etat du tracker (c'est ici qu'on detecte "en ligne")
// ---------------------------------------------------------------------
app.post("/status", (req, res) => {
  const { serialNumber, data } = req.body;

  try {
    const list = typeof data === "string" ? JSON.parse(data) : data || [];
    list.forEach(upsertDeviceFromStatus);
  } catch (err) {
    console.error("Erreur parsing /status:", err.message);
  }

  // Il FAUT repondre avec le serialNumber en moins de 5s, sinon
  // la plateforme considere le push comme echoue et le renvoie.
  res.type("text/plain");
  res.send(String(serialNumber || ""));
});

// ---------------------------------------------------------------------
// 3) alarm : evenements d'alarme
// ---------------------------------------------------------------------
app.post("/alarm", (req, res) => {
  const { serialNumber, data } = req.body;

  try {
    const list = typeof data === "string" ? JSON.parse(data) : data || [];
    list.forEach(recordAlarm);
  } catch (err) {
    console.error("Erreur parsing /alarm:", err.message);
  }

  res.type("text/plain");
  res.send(String(serialNumber || ""));
});

// ---------------------------------------------------------------------
// API de lecture pour le tableau de bord
// ---------------------------------------------------------------------
function checkToken(req, res, next) {
  if (!DASHBOARD_TOKEN) return next(); // pas de protection si non configure
  const token = req.query.token || req.headers["x-dashboard-token"];
  if (token === DASHBOARD_TOKEN) return next();
  return res.status(401).json({ error: "Unauthorized" });
}

app.get("/api/devices", checkToken, (req, res) => {
  const devices = loadDevices();
  const list = Object.values(devices).map((d) => ({
    ...d,
    status: computeStatus(d),
    lastServerSeenAgoSec: d.lastServerSeenAt
      ? Math.round((Date.now() - d.lastServerSeenAt) / 1000)
      : null,
  }));
  list.sort((a, b) => (b.lastServerSeenAt || 0) - (a.lastServerSeenAt || 0));
  res.json({ offlineAfterMin: OFFLINE_AFTER_MIN, devices: list });
});

app.listen(PORT, () => {
  console.log(`GPS SIM monitor en ecoute sur le port ${PORT}`);
  console.log(`Endpoints a communiquer au technicien 18gps.net :`);
  console.log(`  - PushTest : http(s)://<votre-domaine>/pushTest`);
  console.log(`  - status   : http(s)://<votre-domaine>/status`);
  console.log(`  - alarm    : http(s)://<votre-domaine>/alarm`);
});
